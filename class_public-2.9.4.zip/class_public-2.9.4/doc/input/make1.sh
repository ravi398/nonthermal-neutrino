#!/bin/bash
 
doxygen doxyconf

cp doxygen.sty ../manual/latex/doxygen.sty